#!/bin/bash

bail_out()
#Exit code
{
echo "Exiting...."
exit 0
}
