## Introduction

This is a collection of code/functions/templates/methodologies I've put together over 20 years of coding.

* Error handling/tracing
* Help
* Robust CLI argument handling

