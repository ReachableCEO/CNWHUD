#!/bin/bash

function LookupKV()
{

#Arguments:
#$1 <path to key/value table>
#$2 unique record identifier

#Returns:
#Variable/array containing all the values in the record

}
